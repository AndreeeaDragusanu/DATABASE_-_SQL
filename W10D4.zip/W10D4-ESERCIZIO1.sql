USE VIDEOGIOCODB;

-- Seleziona tutti gli impiegati con una laurea in Economia
SELECT 
    *
FROM
    IMPIEGATO
WHERE
    TITOLOSTUDIO LIKE 'laurea in Economia';

-- Seleziona gli impiegati che lavorano come Cassiere o che hanno un Diploma di Informatica
SELECT 
    *
FROM
    IMPIEGATO
        JOIN
    SERVIZIOIMPIEGATO ON IMPIEGATO.CODICEFISCALE = SERVIZIOIMPIEGATO.CODICEFISCALE
WHERE
    CARICA LIKE 'Cassiere'
        OR TITOLOSTUDIO LIKE 'Diploma di Informatica';
        
-- Seleziona i nomi e i titoli degli impiegati che hanno iniziato a lavorare dopo il 1 gennaio 2023
SELECT 
    NOME, TITOLOSTUDIO
FROM
    IMPIEGATO
        JOIN
    SERVIZIOIMPIEGATO ON IMPIEGATO.CODICEFISCALE = SERVIZIOIMPIEGATO.CODICEFISCALE
WHERE
    DATAINIZIO > 01 - 01 - 2023;
    
-- Seleziona i titoli di studio distinti tra gli impiegati
SELECT DISTINCT
    TITOLOSTUDIO
FROM
    IMPIEGATO;

-- Seleziona gli impiegati con un titolo di studio diverso da "Laurea in Economia"
SELECT 
    *
FROM
    IMPIEGATO
WHERE
    TITOLOSTUDIO NOT LIKE 'Laurea in Economia';

-- Seleziona gli impiegati che hanno iniziato a lavorare prima del 1 luglio 2023 e sono Commessi
SELECT 
    *
FROM
    IMPIEGATO
        JOIN
    SERVIZIOIMPIEGATO ON IMPIEGATO.CODICEFISCALE = SERVIZIOIMPIEGATO.CODICEFISCALE
WHERE
    DATAINIZIO <"2023-07-01"
        AND CARICA LIKE 'Commesso';
        
-- Seleziona i titoli e gli sviluppatori dei videogiochi distribuiti nel 2020.
SELECT 
    TITOLO, SVILUPPATORE
FROM
    VIDEOGIOCO
WHERE
    ANNODISTRIBUZIONE = 2020;
    

