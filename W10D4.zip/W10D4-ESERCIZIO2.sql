USE GESTIONALE;

-- Seleziona tutti i prodotti con un prezzo superiore a 50 euro dalla tabella Prodotti.
SELECT 
    *
FROM
    PRODOTTI
WHERE
    PREZZO > 50;
    
-- Seleziona tutte le email dei clienti il cui nome inizia con la lettera 'A' dalla tabella Clienti.
SELECT EMAIL FROM CLIENTI WHERE NOME LIKE "A%";

-- Seleziona tutti gli ordini con una quantità maggiore di 10 o con un importo totale inferiore a 100 euro dalla tabella Ordini
SELECT 
    *
FROM
    ORDINI
        JOIN
    DETTAGLIO_ORDINI ON ORDINI.IDORDINE = DETTAGLIO_ORDINI.IDORDINE
WHERE
    QUANTITA > 10 OR PREZZOTOTALE < 100;
    
-- Seleziona tutti i prezzi dei prodotti il cui nome contiene la parola 'tech' indipendentemente dalla posizione nella tabella Prodotti.
SELECT 
    PREZZO
FROM
    PRODOTTI
WHERE
    NOMEPRODOTTO LIKE '%TECH%';

-- Seleziona tutti i clienti che non hanno un indirizzo email nella tabella Clienti.
SELECT 
    *
FROM
    CLIENTI
WHERE
    EMAIL LIKE '';
    
-- Seleziona tutti i prodotti il cui nome inizia con 'M' e termina con 'e' indipendentemente dalla lunghezza della parola nella tabella Prodotti.
SELECT 
    *
FROM
    PRODOTTI
WHERE
    NOMEPRODOTTO LIKE 'M%e';
    